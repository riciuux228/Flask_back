package com.online.edu.ucenterservice.mapper;

import com.online.edu.ucenterservice.pojo.StatisticsLunbotu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 轮播图信息 Mapper 接口
 * </p>
 *
 * @author 许JIAN林
 * @since 2020-02-06
 */
public interface StatisticsLunbotuMapper extends BaseMapper<StatisticsLunbotu> {

}
