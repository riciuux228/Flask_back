package com.online.edu.common.enums;

/**
 * @描述:
 * @作者: XUJIANLIN
 */

public interface CodeEnum {
    Integer getCode();
}
